semana = ["lunes","martes","miércoles","jueves","viernes","sábado","domingo"]
puts "Array en Ruby"
puts semana
puts "\nMétodo to_s"
puts semana.to_s
puts "\nMétodo join"
puts semana.join (",")
puts "\nMétodo first"
puts semana.first
puts "\nMétodo last"
puts semana.last
puts "\nMétodo length"
puts semana.length
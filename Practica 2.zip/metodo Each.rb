semana = ["lunes","martes","miércoles","jueves","viernes","sábado","domingo"]
i= 0
semana.each do |dia|
puts "dia " + i.to_s + "=" + dia
i +=1
end
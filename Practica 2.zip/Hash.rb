colorHash = {}
colorHash['rojo '] = '#FF0000'
colorHash['verde'] = '#008000'
colorHash['azul '] = '#0000FF'
colorHash.each do |tipoCodigo, color|
puts tipoCodigo + ' : ' + color
end
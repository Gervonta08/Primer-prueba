#array
semana=["lunes","martes","miércoles","jueves","viernes","sábado","domingo"]
puts semana
puts "\nImprimir por posición"
puts semana [1]
puts semana [3]
puts semana [5]
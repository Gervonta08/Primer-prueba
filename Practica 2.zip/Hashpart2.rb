user = {}
user = { :name => "Juan Pérez", :email => "JuanP@example.com" }
puts "Nombre de usuario: #{user [:name]} "
puts "\nCorreo: #{user [:email]}"
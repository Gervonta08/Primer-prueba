semana = ["lunes","martes","miércoles","jueves","viernes","sábado","domingo"]
puts "Array completo"
puts semana.to_s
puts "\nMétodo POP"
puts semana.pop
puts "\nMétodo length"
puts semana.length
puts "\nÚltimo dato"
puts semana.last
puts "\nMétodo PUSH"
puts semana.push "final"
puts "\nTamaño nuevo"
puts semana.length